import { Client } from 'pg';
import { readdirSync, readFileSync } from 'fs';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';

async function getClient() {
  const secretArn = process.env.DB_SECRET_ARN!;
  const sm = new SecretsManagerClient({});
  const sec = await sm.send(new GetSecretValueCommand({ SecretId: secretArn }));
  const { username, password, host, port, dbname } = JSON.parse(sec.SecretString as string);
  const client = new Client({ user: username, password, host, port, database: dbname, ssl: { rejectUnauthorized: false } });
  await client.connect();
  return client;
}

async function main() {
  const client = await getClient();
  const files = readdirSync('./db/migrations').filter(f => f.endsWith('.sql')).sort();
  for (const f of files) {
    const sql = readFileSync(`./db/migrations/${f}`, 'utf8');
    console.log('Applying', f);
    await client.query(sql);
  }
  await client.end();
  console.log('Migrations applied.');
}

main().catch(e => { console.error(e); process.exit(1); });
