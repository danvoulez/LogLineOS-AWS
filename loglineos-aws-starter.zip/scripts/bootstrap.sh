#!/usr/bin/env bash
set -euo pipefail

# Intended to be run in AWS CloudShell with Node.js 20 and CDK v2 preinstalled.
# 1) Install deps
npm ci

# 2) Bootstrap CDK (creates required roles/buckets)
npm -w infra run cdk:bootstrap

# 3) Deploy infra & app stacks
npm -w infra run cdk:deploy

# 4) Run DB migrations & seeds using the Lambda environment (requires DB_SECRET_ARN)
export DB_SECRET_ARN=$(aws secretsmanager list-secrets --query "SecretList[?Name=='LogLineOS-Platform/DbSecret'].ARN" --output text || true)
if [ -z "$DB_SECRET_ARN" ]; then
  echo "Could not auto-detect DB secret. Please set DB_SECRET_ARN manually and re-run steps 4-5."
else
  echo "DB_SECRET_ARN=$DB_SECRET_ARN"
  node --loader ts-node/esm scripts/migrate.ts
  node --loader ts-node/esm scripts/seed.ts
fi

echo "Bootstrap complete."
