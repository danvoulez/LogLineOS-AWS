import { Client } from 'pg';
import { readFileSync } from 'fs';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';

async function getClient() {
  const secretArn = process.env.DB_SECRET_ARN!;
  const sm = new SecretsManagerClient({});
  const sec = await sm.send(new GetSecretValueCommand({ SecretId: secretArn }));
  const { username, password, host, port, dbname } = JSON.parse(sec.SecretString as string);
  const client = new Client({ user: username, password, host, port, database: dbname, ssl: { rejectUnauthorized: false } });
  await client.connect();
  return client;
}

async function main() {
  const client = await getClient();
  const lines = readFileSync('./db/seeds/spans.ndjson', 'utf8').trim().split(/\r?\n/);
  for (const line of lines) {
    const o = JSON.parse(line);
    await client.query(
      `insert into spans(kind, name, status, visibility, data) values ($1,$2,$3,$4,$5) on conflict do nothing`,
      [o.kind, o.name, o.status, o.visibility, o.data]
    );
  }
  await client.end();
  console.log('Seeds applied.');
}

main().catch(e => { console.error(e); process.exit(1); });
