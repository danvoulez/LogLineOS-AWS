create table if not exists policies (
  id bigserial primary key,
  name text not null,
  policy jsonb not null,
  created_at timestamptz default now()
);
