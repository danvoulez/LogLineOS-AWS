create table if not exists spans (
  id bigserial primary key,
  kind text not null,                -- request | execution | function | policy | prompt | memory | provider | ...
  name text not null,
  status text not null,              -- scheduled | running | done | slow | failed
  parent_id bigint references spans(id),
  owner_id text,
  tenant_id text,
  visibility text default 'private', -- private | tenant | public
  data jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists spans_kind_status_idx on spans(kind, status);
create index if not exists spans_visibility_idx on spans(visibility);
create index if not exists spans_parent_idx on spans(parent_id);
create index if not exists spans_tenant_owner_idx on spans(tenant_id, owner_id);

-- simple trigger to update updated_at
create or replace function touch_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists spans_touch on spans;
create trigger spans_touch before update on spans
for each row execute procedure touch_updated_at();
