create table if not exists memory (
  id bigserial primary key,
  key text not null,
  value jsonb not null,
  owner_id text,
  tenant_id text,
  visibility text default 'private', -- private | tenant | public
  created_at timestamptz default now()
);

create index if not exists memory_key_idx on memory(key);
create index if not exists memory_owner_idx on memory(owner_id);
