create or replace view visible_timeline as
select id, kind, name, status, parent_id, visibility, data, created_at, updated_at
from spans
where visibility in ('public','tenant','private');
