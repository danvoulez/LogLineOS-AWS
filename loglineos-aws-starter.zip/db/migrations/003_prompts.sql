create table if not exists prompts (
  id bigserial primary key,
  name text not null,
  compiled_hash text not null,
  graph jsonb not null,
  created_at timestamptz default now()
);
create unique index if not exists prompts_hash_idx on prompts(compiled_hash);
