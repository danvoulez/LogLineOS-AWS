import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import { Client } from 'pg';

const sm = new SecretsManagerClient({});

export const handler = async () => {
  const secretArn = process.env.DB_SECRET_ARN!;
  const sec = await sm.send(new GetSecretValueCommand({ SecretId: secretArn }));
  const { username, password, host, port, dbname } = JSON.parse(sec.SecretString!);
  const client = new Client({ user: username, password, host, port, database: dbname, ssl: { rejectUnauthorized: false } });
  await client.connect();

  // 1) pick next scheduled request
  const { rows } = await client.query(
    `select id, data from spans where kind='request' and status='scheduled' order by created_at asc limit 1`
  );

  if (rows.length === 0) {
    await client.end(); 
    return { ok: true, message: 'no scheduled requests' };
  }

  const req = rows[0];
  // 2) mark as running
  await client.query(`update spans set status='running' where id=$1`, [req.id]);

  // 3) simulate execution and emit execution span
  const result = { echo: req.data?.input ?? null, ts: new Date().toISOString() };

  await client.query(
    `insert into spans(kind, name, status, parent_id, visibility, data)
     values ('execution', 'run_code', 'done', $1, 'private', $2)`,
    [req.id, JSON.stringify({ result })]
  );

  // 4) mark request as done
  await client.query(`update spans set status='done' where id=$1`, [req.id]);
  await client.end();
  return { ok: true, executed_request: req.id };
};
