import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import { Client } from 'pg';

const sm = new SecretsManagerClient({});

export const handler = async () => {
  const secretArn = process.env.DB_SECRET_ARN!;
  const sec = await sm.send(new GetSecretValueCommand({ SecretId: secretArn }));
  const { username, password, host, port, dbname } = JSON.parse(sec.SecretString!);
  const client = new Client({ user: username, password, host, port, database: dbname, ssl: { rejectUnauthorized: false } });
  await client.connect();

  // Placeholder: mark slow requests older than 30s
  await client.query(
    `update spans set status='slow' where kind='request' and status='running' and now() - updated_at > interval '30 seconds'`
  );
  await client.end();
  return { ok: true };
};
