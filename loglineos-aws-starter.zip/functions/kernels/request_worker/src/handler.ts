import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import { Client } from 'pg';

const sm = new SecretsManagerClient({});

export const handler = async () => {
  const secretArn = process.env.DB_SECRET_ARN!;
  const sec = await sm.send(new GetSecretValueCommand({ SecretId: secretArn }));
  const { username, password, host, port, dbname } = JSON.parse(sec.SecretString!);
  const client = new Client({ user: username, password, host, port, database: dbname, ssl: { rejectUnauthorized: false } });
  await client.connect();

  // This worker triggers the run_code execution indirectly (simple model).
  await client.query(
    `insert into spans(kind, name, status, visibility, data) values ('request','run_code','scheduled','private','{}')`
  );

  await client.end();
  return { ok: true };
};
