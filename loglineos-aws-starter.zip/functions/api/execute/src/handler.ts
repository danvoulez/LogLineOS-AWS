import { APIGatewayProxyHandlerV2 } from 'aws-lambda';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import { Client } from 'pg';

const sm = new SecretsManagerClient({});

export const handler: APIGatewayProxyHandlerV2 = async (event) => {
  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const { function_name, input, owner_id, tenant_id } = body;

    const secretArn = process.env.DB_SECRET_ARN!;
    const sec = await sm.send(new GetSecretValueCommand({ SecretId: secretArn }));
    const { username, password, host, port, dbname } = JSON.parse(sec.SecretString!);

    const client = new Client({ user: username, password, host, port, database: dbname, ssl: { rejectUnauthorized: false } });
    await client.connect();

    // Create a request span
    const res = await client.query(
      `insert into spans(kind, name, status, owner_id, tenant_id, visibility, data)
       values ($1,$2,$3,$4,$5,'private', $6) returning id`,
      ['request', function_name, 'scheduled', owner_id, tenant_id, JSON.stringify({ input })]
    );

    await client.end();
    return { statusCode: 200, body: JSON.stringify({ request_id: res.rows[0].id }) };
  } catch (e: any) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
