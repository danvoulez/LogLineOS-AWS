import { APIGatewayProxyHandlerV2 } from 'aws-lambda';

export const handler: APIGatewayProxyHandlerV2 = async () => {
  // Note: ALB + Lambda is better for long SSE streams; here we send a stub.
  return {
    statusCode: 200,
    headers: {
      'content-type': 'text/event-stream',
      'cache-control': 'no-cache',
      'connection': 'keep-alive'
    },
    body: `event: ping\ndata: ok\n\n`
  };
};
