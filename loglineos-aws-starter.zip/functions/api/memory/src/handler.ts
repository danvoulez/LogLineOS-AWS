import { APIGatewayProxyHandlerV2 } from 'aws-lambda';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import { Client } from 'pg';

const sm = new SecretsManagerClient({});

export const handler: APIGatewayProxyHandlerV2 = async (event) => {
  const method = event.requestContext.http.method;
  const secretArn = process.env.DB_SECRET_ARN!;
  const sec = await sm.send(new GetSecretValueCommand({ SecretId: secretArn }));
  const { username, password, host, port, dbname } = JSON.parse(sec.SecretString!);
  const client = new Client({ user: username, password, host, port, database: dbname, ssl: { rejectUnauthorized: false } });
  await client.connect();

  try {
    if (method === 'POST') {
      const body = event.body ? JSON.parse(event.body) : {};
      const { key, value, owner_id, tenant_id, visibility='private' } = body;
      const r = await client.query(
        `insert into memory(key, value, owner_id, tenant_id, visibility) values ($1,$2,$3,$4,$5) returning id`,
        [key, value, owner_id, tenant_id, visibility]
      );
      return { statusCode: 200, body: JSON.stringify({ id: r.rows[0].id }) };
    } else {
      const { key, owner_id } = event.queryStringParameters || {};
      const r = await client.query(
        `select id, key, value, visibility, created_at from memory where owner_id = $1 and key = $2 order by created_at desc limit 50`,
        [owner_id, key]
      );
      return { statusCode: 200, body: JSON.stringify(r.rows) };
    }
  } catch (e:any) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  } finally {
    await client.end();
  }
};
