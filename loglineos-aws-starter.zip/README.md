# LogLineOS — AWS Hands‑Off Starter

Este monorepo entrega uma **plataforma 100% AWS** para operar o **LogLineOS core**:
ledger (Postgres/Aurora), kernels (`run_code`, `request_worker`, `policy_agent`),
APIs (execute, timeline stream, memory), onboarding de apps, prompt system agnóstico de LLM
e observabilidade — tudo **automatizado** via CDK + CodePipeline.

> Objetivo: **git push → produção**, sem toque manual no dia a dia.

---

## Arquitetura (resumo)

- **Aurora PostgreSQL (Multi‑AZ)** + RDS Proxy — ledger universal (`spans`) com views, RLS e índices.
- **Lambda** (Node.js 20) — kernels e APIs.
- **API Gateway (HTTP API)** — `/api/execute`, `/api/timeline/stream`, `/api/memory`.
- **EventBridge** — agendamento dos bots (minutely), TTL reaper (diário), rollups (horário).
- **KMS + Secrets Manager** — chaves por tenant e segredos de provedores LLM.
- **CloudWatch** — logs, métricas, alarmes.
- **CodePipeline** — CI/CD zero‑toque (plan→apply→migrate→seed→smoke).

---

## Zero‑toque (como funciona)

1. Commit no branch `main` dispara a pipeline.
2. Pipeline cria/atualiza **infra** (CDK), aplica **migrações SQL**, injeta **seeds NDJSON** (kernels/policies/prompts),
   e roda **smoke tests** E2E (`request → run_code → execution`).
3. Caso algo falhe, o deploy é automaticamente revertido.

> *Nota:* A primeira vez requer o **bootstrap** da pipeline e do CDK (via CloudShell).
Incluímos um script `scripts/bootstrap.sh` que faz isso em ~1 comando, sem telas manuais.

---

## Pastas

```
infra/                # Stacks CDK (VPC, Aurora, Lambdas, API, Events, Pipeline)
functions/            # Código Lambda (APIs e kernels)
db/
  migrations/         # SQL (schema+RLS+índices)
  seeds/              # NDJSON (spans de kernels, policies, prompts)
scripts/              # bootstrap, migração e seeders (idempotentes)
.github/workflows/    # (opcional) GitHub Actions para lint/test
```

---

## Fluxo local (opcional)
- `npm run lint` — valida sintaxe.
- `npm run build` — compila lambdas (esbuild).
- `npm run test` — testes unitários básicos.

---

## Segurança
- IAM mínimo por Lambda (principle of least privilege).
- Segredos em **Secrets Manager**, nenhuma credencial em variável de ambiente.
- RLS por `owner_id`, `tenant_id`, `visibility` no ledger.
- Tracing com correlation/traceId em todos os spans de execução.

---

## Licença
MIT — use como base e adapte ao seu ecossistema.
