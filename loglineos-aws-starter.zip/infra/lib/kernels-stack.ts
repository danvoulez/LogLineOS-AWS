import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as lambda from 'aws-cdk-lib/aws-lambda-nodejs';
import * as secrets from 'aws-cdk-lib/aws-secretsmanager';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as path from 'path';

interface KernelsStackProps extends cdk.StackProps {
  vpc: ec2.IVpc;
  db: rds.IDatabaseInstance;
  dbSecret: secrets.ISecret;
}

export class KernelsStack extends cdk.Stack {
  public readonly runCode: lambda.NodejsFunction;
  public readonly requestWorker: lambda.NodejsFunction;
  public readonly policyAgent: lambda.NodejsFunction;

  constructor(scope: Construct, id: string, props: KernelsStackProps) {
    super(scope, id, props);

    const common = {
      runtime: lambda.Runtime.NODEJS_20_X,
      memorySize: 512,
      timeout: cdk.Duration.seconds(30),
      vpc: props.vpc,
      environment: {
        DB_SECRET_ARN: props.dbSecret.secretArn
      },
      bundling: { minify: true, externalModules: ['pg-native'] }
    };

    this.runCode = new lambda.NodejsFunction(this, 'RunCode', {
      entry: path.join(__dirname, '../../functions/kernels/run_code/src/handler.ts'),
      ...common
    });

    this.requestWorker = new lambda.NodejsFunction(this, 'RequestWorker', {
      entry: path.join(__dirname, '../../functions/kernels/request_worker/src/handler.ts'),
      ...common
    });

    this.policyAgent = new lambda.NodejsFunction(this, 'PolicyAgent', {
      entry: path.join(__dirname, '../../functions/kernels/policy_agent/src/handler.ts'),
      ...common
    });

    // Secrets permissions
    props.dbSecret.grantRead(this.runCode);
    props.dbSecret.grantRead(this.requestWorker);
    props.dbSecret.grantRead(this.policyAgent);

    // Allow to connect to RDS through proxy
    this.runCode.addToRolePolicy(new iam.PolicyStatement({
      actions: ['rds-db:connect'],
      resources: ['*']
    }));
    this.requestWorker.addToRolePolicy(new iam.PolicyStatement({
      actions: ['rds-db:connect'],
      resources: ['*']
    }));
    this.policyAgent.addToRolePolicy(new iam.PolicyStatement({
      actions: ['rds-db:connect'],
      resources: ['*']
    }));
  }
}
