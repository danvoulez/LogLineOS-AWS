import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as secrets from 'aws-cdk-lib/aws-secretsmanager';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as iam from 'aws-cdk-lib/aws-iam';

export class PlatformStack extends cdk.Stack {
  public readonly vpc: ec2.Vpc;
  public readonly db: rds.DatabaseInstance;
  public readonly dbSecret: secrets.Secret;
  public readonly rdsProxy: rds.DatabaseProxy;
  public readonly kmsKey: kms.Key;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    this.vpc = new ec2.Vpc(this, 'Vpc', {
      maxAzs: 2,
      natGateways: 1
    });

    this.kmsKey = new kms.Key(this, 'DataKey', {
      enableKeyRotation: true,
      alias: 'alias/loglineos-data'
    });

    this.dbSecret = new secrets.Secret(this, 'DbSecret', {
      generateSecretString: {
        secretStringTemplate: JSON.stringify({ username: 'postgres' }),
        generateStringKey: 'password',
        excludePunctuation: true
      }
    });

    const sg = new ec2.SecurityGroup(this, 'DbSg', { vpc: this.vpc });

    this.db = new rds.DatabaseInstance(this, 'AuroraPg', {
      vpc: this.vpc,
      engine: rds.DatabaseInstanceEngine.postgres({ version: rds.PostgresEngineVersion.VER_15 }),
      credentials: rds.Credentials.fromSecret(this.dbSecret),
      multiAz: true,
      allocatedStorage: 100,
      storageEncrypted: true,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      securityGroups: [sg],
      backupRetention: cdk.Duration.days(7)
    });

    // RDS Proxy for Lambda
    this.rdsProxy = new rds.DatabaseProxy(this, 'RdsProxy', {
      proxyTarget: rds.ProxyTarget.fromInstance(this.db),
      secrets: [this.dbSecret],
      vpc: this.vpc,
      requireTLS: true,
      maxConnectionsPercent: 90
    });

    // Allow Lambdas in account to use the KMS key (tighten in production per-role)
    this.kmsKey.addToResourcePolicy(new iam.PolicyStatement({
      actions: ['kms:Decrypt','kms:Encrypt','kms:GenerateDataKey*'],
      principals: [new iam.AccountRootPrincipal()],
      resources: ['*']
    }));
  }
}
