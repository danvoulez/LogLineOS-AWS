import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import { KernelsStack } from './kernels-stack';

interface EventsStackProps extends cdk.StackProps {
  kernels: KernelsStack;
}

export class EventsStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: EventsStackProps) {
    super(scope, id, props);

    // Run request worker every minute
    new events.Rule(this, 'RequestWorkerSchedule', {
      schedule: events.Schedule.rate(cdk.Duration.minutes(1)),
      targets: [new targets.LambdaFunction(props.kernels.requestWorker)]
    });

    // Run policy agent every minute
    new events.Rule(this, 'PolicyAgentSchedule', {
      schedule: events.Schedule.rate(cdk.Duration.minutes(1)),
      targets: [new targets.LambdaFunction(props.kernels.policyAgent)]
    });

    // TODO: add TTL reaper daily
  }
}
