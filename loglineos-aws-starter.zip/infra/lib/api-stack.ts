import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as apigwv2 from 'aws-cdk-lib/aws-apigatewayv2';
import * as integrations from 'aws-cdk-lib/aws-apigatewayv2-integrations';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as lambda from 'aws-cdk-lib/aws-lambda-nodejs';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as secrets from 'aws-cdk-lib/aws-secretsmanager';
import * as path from 'path';

interface ApiStackProps extends cdk.StackProps {
  vpc: ec2.IVpc;
  rdsProxy: rds.IDatabaseProxy;
  dbSecret: secrets.ISecret;
}

export class ApiStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: ApiStackProps) {
    super(scope, id, props);

    const common = {
      runtime: lambda.Runtime.NODEJS_20_X,
      memorySize: 512,
      timeout: cdk.Duration.seconds(30),
      vpc: props.vpc,
      environment: {
        DB_SECRET_ARN: props.dbSecret.secretArn
      }
    };

    const executeFn = new lambda.NodejsFunction(this, 'ApiExecute', {
      entry: path.join(__dirname, '../../functions/api/execute/src/handler.ts'),
      ...common
    });

    const memoryFn = new lambda.NodejsFunction(this, 'ApiMemory', {
      entry: path.join(__dirname, '../../functions/api/memory/src/handler.ts'),
      ...common
    });

    const streamFn = new lambda.NodejsFunction(this, 'ApiTimelineStream', {
      entry: path.join(__dirname, '../../functions/api/timeline_stream/src/handler.ts'),
      timeout: cdk.Duration.seconds(60),
      ...common
    });

    props.dbSecret.grantRead(executeFn);
    props.dbSecret.grantRead(memoryFn);
    props.dbSecret.grantRead(streamFn);

    const httpApi = new apigwv2.HttpApi(this, 'HttpApi');

    httpApi.addRoutes({
      path: '/api/execute',
      methods: [apigwv2.HttpMethod.POST],
      integration: new integrations.HttpLambdaIntegration('ExecuteIntegration', executeFn)
    });

    httpApi.addRoutes({
      path: '/api/memory',
      methods: [apigwv2.HttpMethod.GET, apigwv2.HttpMethod.POST],
      integration: new integrations.HttpLambdaIntegration('MemoryIntegration', memoryFn)
    });

    httpApi.addRoutes({
      path: '/api/timeline/stream',
      methods: [apigwv2.HttpMethod.GET],
      integration: new integrations.HttpLambdaIntegration('StreamIntegration', streamFn)
    });

    new cdk.CfnOutput(this, 'ApiUrl', { value: httpApi.apiEndpoint });
  }
}
