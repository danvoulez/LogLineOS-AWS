import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as codepipeline from 'aws-cdk-lib/aws-codepipeline';
import * as codepipeline_actions from 'aws-cdk-lib/aws-codepipeline-actions';
import * as codebuild from 'aws-cdk-lib/aws-codebuild';

export class PipelineStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Minimal placeholder pipeline (source from CodeCommit/S3/GitHub to be wired later).
    const pipeline = new codepipeline.Pipeline(this, 'Pipeline');

    const source = new codepipeline.Artifact();
    const build = new codepipeline.Artifact();

    pipeline.addStage({
      stageName: 'Source',
      actions: [
        new codepipeline_actions.GitHubSourceAction({
          actionName: 'GitHub',
          owner: 'YOUR_GITHUB_ORG',
          repo: 'loglineos-aws-starter',
          oauthToken: cdk.SecretValue.secretsManager('github-oauth-token-placeholder'),
          output: source,
          branch: 'main'
        })
      ]
    });

    pipeline.addStage({
      stageName: 'BuildAndSynth',
      actions: [
        new codepipeline_actions.CodeBuildAction({
          actionName: 'Build',
          input: source,
          outputs: [build],
          project: new codebuild.PipelineProject(this, 'BuildProject', {
            buildSpec: codebuild.BuildSpec.fromObject({
              version: '0.2',
              phases: {
                install: { commands: ['npm i -g npm', 'npm ci'] },
                build: { commands: ['npm run build'] }
              },
              artifacts: { 'base-directory': '.', files: ['**/*'] }
            })
          })
        })
      ]
    });

    // You can add a 'Deploy' stage that runs `cdk deploy --all` if you prefer.
  }
}
